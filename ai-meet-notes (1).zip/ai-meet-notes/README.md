# AI Meeting Notes Summarizer (React + Node + Mongo)

## Run
### Backend
```bash
cd server
cp .env.example .env
npm i
npm run dev
```
### Frontend
```bash
cd web
cp .env.example .env
npm i
npm run dev
```
Open http://localhost:5173
