import { Router } from 'express';
import Meeting from '../models/Meeting.js';
import { requireAuth } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';
import { genShareId } from '../utils/shareId.js';
import { transcribeAudio, summarizeText } from '../services/ai.js';

const r = Router();

// Create meeting from TEXT or AUDIO
r.post('/create', requireAuth, upload.single('audio'), async (req, res) => {
  const { title, text } = req.body;
  const audioPath = req.file?.path;

  let transcript = text || '';
  if (!transcript && audioPath) {
    transcript = await transcribeAudio(audioPath);
  }

  const { summary, actionItems } = await summarizeText(transcript || '');

  const meeting = await Meeting.create({
    owner: req.user.id,
    title: title || 'Untitled meeting',
    rawText: text,
    audioPath,
    transcript,
    summary,
    actionItems
  });
  res.json(meeting);
});

// List my meetings
r.get('/mine', requireAuth, async (req, res) => {
  const items = await Meeting.find({ owner: req.user.id }).sort({ createdAt: -1 });
  res.json(items);
});

// Get one (private)
r.get('/:id', requireAuth, async (req, res) => {
  const m = await Meeting.findOne({ _id: req.params.id, owner: req.user.id });
  if (!m) return res.status(404).json({ error: 'Not found' });
  res.json(m);
});

// Toggle share public link
r.post('/:id/share', requireAuth, async (req, res) => {
  const m = await Meeting.findOne({ _id: req.params.id, owner: req.user.id });
  if (!m) return res.status(404).json({ error: 'Not found' });
  if (!m.isPublic) {
    m.isPublic = true;
    m.shareId = m.shareId || genShareId();
  } else {
    m.isPublic = false;
  }
  await m.save();
  res.json({ isPublic: m.isPublic, shareId: m.shareId });
});

// Public view by shareId
r.get('/public/:shareId', async (req, res) => {
  const m = await Meeting.findOne({ shareId: req.params.shareId, isPublic: true });
  if (!m) return res.status(404).json({ error: 'Not found' });
  res.json({
    title: m.title,
    transcript: m.transcript,
    summary: m.summary,
    actionItems: m.actionItems,
    createdAt: m.createdAt
  });
});

export default r;
