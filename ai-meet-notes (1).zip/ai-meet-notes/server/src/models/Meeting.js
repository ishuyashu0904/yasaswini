import mongoose from 'mongoose';

const meetingSchema = new mongoose.Schema(
  {
    owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, default: 'Untitled meeting' },
    rawText: { type: String },
    audioPath: { type: String },
    transcript: { type: String },
    summary: { type: String },
    actionItems: [{ type: String }],
    shareId: { type: String, index: true },
    isPublic: { type: Boolean, default: false }
  },
  { timestamps: true }
);

export default mongoose.model('Meeting', meetingSchema);
