/**
 * AI layer stubs. Plug your real providers here.
 * - transcribeAudio(filePath) => transcript string
 * - summarizeText(text) => { summary, actionItems[] }
 */

export async function transcribeAudio(filePath) {
  // TODO: call Whisper / Google STT.
  // For now, fake it to keep the app runnable.
  return `TRANSCRIPT (demo): Discussed timeline, blockers, and budget for Q3. File=${filePath}`;
}

export async function summarizeText(text) {
  // TODO: call OpenAI/HuggingFace for real summarization.
  // Simple heuristic demo summary + naive action list extraction.
  const lines = text.split(/\n|\.\s/).filter(Boolean);
  const summary = lines.slice(0, 3).join('. ') + (lines.length > 3 ? '...' : '');
  const actionItems = lines
    .filter(l => /\b(action|todo|task|assign|deadline|by|owner)\b/i.test(l))
    .slice(0, 5);
  return { summary: summary || 'No content', actionItems };
}
