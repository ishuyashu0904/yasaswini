import { Link } from 'react-router-dom';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="mx-auto max-w-5xl p-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold">AI Meeting Notes</h1>
        <nav className="space-x-4">
          <Link className="text-blue-600" to="/login">Login</Link>
          <Link className="text-blue-600" to="/register">Register</Link>
        </nav>
      </header>
      <main className="mx-auto max-w-3xl p-6">
        <h2 className="text-xl font-semibold mb-2">Summarize calls, share action items.</h2>
        <p className="text-gray-600 mb-6">Upload audio or paste transcript. Get concise notes and share a public link.</p>
        <Link to="/dashboard" className="inline-block bg-blue-600 text-white px-4 py-2 rounded-lg">Open Dashboard</Link>
      </main>
    </div>
  );
}
