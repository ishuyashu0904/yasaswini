import { useEffect, useState } from 'react';
import { meetings } from '../api';

export default function ShareBanner({ shareId }) {
  const [data, setData] = useState(null);
  const [err, setErr] = useState('');
  useEffect(() => {
    meetings.publicView(shareId).then(setData).catch(e=>setErr(e.message));
  }, [shareId]);
  if (err) return <p className="text-red-600">{err}</p>;
  if (!data) return <p>Loading…</p>;
  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <h3 className="font-semibold text-lg">{data.title}</h3>
      <p className="text-gray-700 mt-2 whitespace-pre-wrap">{data.summary}</p>
      {!!data.actionItems?.length && (
        <div className="mt-3">
          <p className="font-medium">Action Items</p>
          <ul className="list-disc ml-6 text-gray-700">
            {data.actionItems.map((a, i) => <li key={i}>{a}</li>)}
          </ul>
        </div>
      )}
      <p className="text-xs text-gray-500 mt-3">Created: {new Date(data.createdAt).toLocaleString()}</p>
    </div>
  );
}
