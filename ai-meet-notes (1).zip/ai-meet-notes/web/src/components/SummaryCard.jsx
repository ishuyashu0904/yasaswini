import { meetings } from '../api';

export default function SummaryCard({ token, item, onChanged }) {
  const toggleShare = async () => {
    const res = await meetings.toggleShare(token, item._id);
    onChanged({ ...item, isPublic: res.isPublic, shareId: res.shareId });
  };

  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <div className="flex justify-between items-start">
        <h4 className="font-semibold text-lg">{item.title}</h4>
        <button onClick={toggleShare} className="text-sm bg-gray-800 text-white px-3 py-1 rounded">
          {item.isPublic ? 'Unshare' : 'Share'}
        </button>
      </div>
      <p className="text-gray-700 mt-2 whitespace-pre-wrap">{item.summary}</p>
      {!!item.actionItems?.length && (
        <div className="mt-3">
          <p className="font-medium">Action Items</p>
          <ul className="list-disc ml-6 text-gray-700">
            {item.actionItems.map((a, i) => <li key={i}>{a}</li>)}
          </ul>
        </div>
      )}
      {item.isPublic && item.shareId && (
        <div className="mt-3 text-sm p-2 bg-gray-50 rounded">
          Public link: <code>{window.location.origin}/#/p/{item.shareId}</code>
        </div>
      )}
    </div>
  );
}
