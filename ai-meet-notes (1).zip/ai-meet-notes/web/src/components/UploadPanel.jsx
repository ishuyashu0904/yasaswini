import { useState } from 'react';
import { meetings } from '../api';

export default function UploadPanel({ token, onCreated }) {
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr('');
    try {
      const m = await meetings.create({ token, title, text, file });
      setTitle(''); setText(''); setFile(null);
      onCreated(m);
    } catch (e) { setErr(e.message); }
    finally { setBusy(false); }
  };

  return (
    <form onSubmit={submit} className="bg-white p-4 rounded-xl shadow mb-4">
      <h3 className="font-semibold mb-2">Create from transcript or audio</h3>
      {err && <p className="text-red-600 mb-2">{err}</p>}
      <input className="w-full border p-2 rounded mb-3" placeholder="Title (optional)" value={title} onChange={e=>setTitle(e.target.value)} />
      <textarea className="w-full border p-2 rounded mb-3" rows="4" placeholder="Paste transcript text (optional)" value={text} onChange={e=>setText(e.target.value)} />
      <input type="file" accept="audio/*" onChange={e=>setFile(e.target.files[0])} className="mb-3" />
      <button disabled={busy} className="bg-blue-600 text-white px-4 py-2 rounded">{busy ? 'Processing…' : 'Create Summary'}</button>
    </form>
  );
}
