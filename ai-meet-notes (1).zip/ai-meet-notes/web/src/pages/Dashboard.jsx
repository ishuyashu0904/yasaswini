import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import UploadPanel from '../components/UploadPanel.jsx';
import SummaryCard from '../components/SummaryCard.jsx';
import ShareBanner from '../components/ShareBanner.jsx';
import { meetings } from '../api';

export default function Dashboard() {
  const nav = useNavigate();
  const token = localStorage.getItem('token');
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  const [items, setItems] = useState([]);

  const location = useLocation();
  const shareId = useMemo(() => {
    const m = location.hash.match(/#\/p\/(.+)$/);
    return m ? m[1] : null;
  }, [location.hash]);

  useEffect(() => {
    if (!token) return nav('/login');
    meetings.mine(token).then(setItems).catch(() => {});
  }, [token]);

  const onCreated = (m) => setItems(prev => [m, ...prev]);
  const onChanged = (m) => setItems(prev => prev.map(x => x._id === m._id ? m : x));

  if (shareId) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="mx-auto max-w-3xl">
          <ShareBanner shareId={shareId} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="mx-auto max-w-5xl p-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <div className="text-sm text-gray-700">{user?.name}</div>
      </header>
      <main className="mx-auto max-w-3xl p-6 space-y-4">
        <UploadPanel token={token} onCreated={onCreated} />
        <div className="grid gap-4">
          {items.map(it => (
            <SummaryCard key={it._id} token={token} item={it} onChanged={onChanged} />
          ))}
          {!items.length && <p className="text-gray-500">No meetings yet. Create your first summary above.</p>}
        </div>
      </main>
    </div>
  );
}
