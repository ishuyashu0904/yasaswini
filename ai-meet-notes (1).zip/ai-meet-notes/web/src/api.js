const API = import.meta.env.VITE_API_URL || 'http://localhost:5000';

export const auth = {
  async login(email, password) {
    const r = await fetch(`${API}/api/auth/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (!r.ok) throw new Error('Login failed');
    return r.json();
  },
  async register(name, email, password) {
    const r = await fetch(`${API}/api/auth/register`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    if (!r.ok) throw new Error('Register failed');
    return r.json();
  }
};

export const meetings = {
  async create({ token, title, text, file }) {
    const fd = new FormData();
    if (title) fd.append('title', title);
    if (text) fd.append('text', text);
    if (file) fd.append('audio', file);
    const r = await fetch(`${API}/api/meetings/create`, {
      method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: fd
    });
    if (!r.ok) throw new Error('Create failed');
    return r.json();
  },
  async mine(token) {
    const r = await fetch(`${API}/api/meetings/mine`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!r.ok) throw new Error('Fetch failed');
    return r.json();
  },
  async toggleShare(token, id) {
    const r = await fetch(`${API}/api/meetings/${id}/share`, {
      method: 'POST', headers: { Authorization: `Bearer ${token}` }
    });
    if (!r.ok) throw new Error('Share failed');
    return r.json();
  },
  async publicView(shareId) {
    const r = await fetch(`${API}/api/meetings/public/${shareId}`);
    if (!r.ok) throw new Error('Not found');
    return r.json();
  }
};
